package fiji.robot; 

import java.awt.event.*; 

class LRFrameAdapter extends WindowAdapter  { 
    public void windowClosing(WindowEvent e) { 
        e.getWindow().dispose(); 
        System.exit(0); 
    } 
} 