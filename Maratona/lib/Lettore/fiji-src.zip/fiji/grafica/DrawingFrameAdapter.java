package fiji.grafica; 

import java.awt.event.*; 

class DrawingFrameAdapter extends WindowAdapter  { 
    public void windowClosing(WindowEvent e) { 
        e.getWindow().dispose(); 
        System.exit(0); 
    } 
} 